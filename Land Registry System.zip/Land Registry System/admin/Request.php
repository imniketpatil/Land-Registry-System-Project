<?php
// ob_start(); 
$conn= mysqli_connect("localhost","root","","landrequest"); 
if(!$conn) { die(" Connection Error "); }

$Id = isset($_POST["id"]);
$Name = isset($_POST["name"]);
$Age = isset($_POST["age"]);
$City = isset($_POST["city"]);
$Contact = isset($_POST["contact"]);
$Aadhar = isset($_POST["aadhar"]);
$Email= isset($_POST["email"]);
$ForProperty= isset($_POST["forproperty"]);
$TimeStamp= isset($_POST["timestamp"]);
// $conn = mysqli_connect("localhost", "root", "", "landrequest") or die("connection failed");
// $sql = "INSERT INTO request( id, name, age, city, contact, aadhar, email) VALUES ('{$Id}','{$Name}','{$Age}','{$City}','{$Contact}','{$Aadhar}','{$Email}')";
// if(mysqli_query($conn, $sql)) {
//     echo "New record created successfully";
// } else {
//     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
// }
//  mysqli_close($conn);
?>