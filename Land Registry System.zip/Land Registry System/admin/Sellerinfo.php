<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>SellerInfo</title>
      <!-- Font Awesome -->
      <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="../asset/css/adminlte.min.css">
      <link rel="stylesheet" href="../asset/css/animate.min.css">
      <link rel="stylesheet" href="../asset/css/style.css">
      <!-- DataTables -->
      <link rel="stylesheet" href="../asset/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
      <link rel="stylesheet" href="../asset/tables/datatables-responsive/css/responsive.bootstrap4.min.css">
      <link rel="stylesheet" href="../asset/tables/datatables-buttons/css/buttons.bootstrap4.min.css">
   </head>
   <body class="hold-transition sidebar-mini layout-fixed">
      <div class="wrapper">
         <!-- Navbar -->
         <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
               
               <li class="nav-item">
                  <a class="nav-link" data-widget="fullscreen" href="logout.php">
                  <i class="fas fa-power-off"></i>
                  </a>
               </li>
            </ul>
         </nav>
         <!-- /.navbar -->
         <!-- Main Sidebar Container -->
         <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
            <!-- Brand Logo -->
            <a href="/admin/Admin_dashboard.html" class="brand-link animated swing">
               <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
               <!-- Sidebar user panel (optional) -->
               <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                  <div class="image">
                     <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
                  </div>
                  <div class="info">
                     <a href="#" class="d-block"></a>
                  </div>
               </div>
               <!-- Sidebar Menu -->
               <nav class="mt-2">
                  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                     data-accordion="false">
                     <li class="nav-item animated bounceInLeft">
                        <a href="Admin_dashboard.php" class="nav-link">
                           <i class="nav-icon fa fa-tachometer-alt"></i>
                           <p>
                              Dashboard
                           </p>
                        </a>
                     </li>
                     <li class="nav-item animated bounceInRight">
                        <a href="Admin_profile.php" class="nav-link">
                           <i class="nav-icon fa fa-users"></i>
                           <p>
                              Admin Profile
                           </p>
                        </a>
                     </li>
                     <li class="nav-item animated bounceInRight">
                        <a href="Buyerinfo.php" class="nav-link">
                           <i class="nav-icon fa fa-users"></i>
                           <p>
                              BuyerInfo
                           </p>
                        </a>
                     </li>
                     <li class="nav-item animated bounceInRight">
                        <a href="Sellerinfo.php" class="nav-link">
                           <i class="nav-icon fa fa-users"></i>
                           <p>
                              SellerInfo
                           </p>
                        </a>
                     </li>
                     <li class="nav-item animated bounceInRight">
                     <a href="Land_Request.php" class="nav-link">
                        <i class="nav-icon fa fa-university"></i>
                        <p>
                           Land Request
                        </p>
                     </a>
                  </li>
                     
                  </ul>
               </nav>
               <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
         </aside>
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
               <div class="container-fluid">
                  <div class="row mb-2">
                     <div class="col-sm-6 animated bounceInRight">
                        <h1 class="m-0">Seller Info</h1>
                     </div>
                     <!-- /.col -->
                     <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                           <li class="breadcrumb-item"><a href="#">Home</a></li>
                           <li class="breadcrumb-item active">SellerInfo</li>
                        </ol>
                     </div>
                     <!-- /.col -->
                  </div>
                  <!-- /.row -->
               </div>
               <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <section class="content">
               <div class="container-fluid">
                  <div class="card-body animated pulse">
                  <table id="example1" class="table table-bordered table-striped">
                 
                 <thead>
                    <tr>
                 
                 <th scope="col">Name</th>
                 <th scope="col">Age</th>
                 <th scope="col">City</th>
                 <th scope="col">Contact</th>
                 <th scope="col">Aadhar</th>
                 <th scope="col">Username</th>
                 <th scope="col">email</th>
                 
         
         
         
         
         
         
         </tr>
         </thead>
         <tbody>
         
         <?php
         include 'configseller.php';
         $pic = mysqli_query($conn,"SELECT * FROM `tb_slogin`");
         while($row = mysqli_fetch_array($pic)){
         echo "<tr>
                 
                 <td>$row[name]</td>
                 <td>$row[age]</td>
                 <td>$row[city]</td>
                 <td>$row[contact]</td>
                 <td>$row[aadhar]</td>
                 <td>$row[username]</td>
                 <td>$row[email]</td>
         
                 
                
                 
                 
                 
                 
             </tr>
             ";
         }
         
         ?>
                  </div>
               </div>
               <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
      </div>
      <!-- ./wrapper -->
      <!-- jQuery -->
      <script src="../asset/jquery/jquery.min.js"></script>
      <script src="../asset/js/bootstrap.bundle.min.js"></script>
      <script src="../asset/js/adminlte.js"></script>
   </body>
</html>