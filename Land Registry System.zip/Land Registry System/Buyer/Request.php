<?php

$Name = $_POST["name"];
$Age = $_POST["age"];
$City = $_POST["city"];
$Contact = $_POST["contact"];
$Aadhar = $_POST["aadhar"];
$Email= $_POST["email"];

$conn = mysqli_connect("localhost", "root", "", "landrequest") or die("connection failed");
$sql ="INSERT INTO request(name, age, city, contact, aadhar, email) VALUES ('{$Name}','{$Age}','{$City}','{$Contact}','{$Aadhar}','{$Email}')";
$result = mysqli_query($conn, $sql) or die("query failed");
header("location: http://localhost/Land%20Registry%20System/Buyer/Land_Request.php");
mysqli_close($conn);
?>