<?php
$conn = mysqli_connect("localhost", "root", "", "addland");

if(!$conn){
    die("Connection Error");
}
?>