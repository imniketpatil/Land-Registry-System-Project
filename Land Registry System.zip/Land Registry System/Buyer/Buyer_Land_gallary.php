<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Buyer Profile</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../asset/css/adminlte.min.css">
    <link rel="stylesheet" href="../asset/css/style.css">
    <link rel="stylesheet" href="style1.css">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                
                <li class="nav-item">
                    <a class="nav-link" data-widget="fullscreen" href="logout.php">
                        <i class="fas fa-power-off"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
         <!-- Brand Logo -->
         <a href="BuyerDashboard.html" class="brand-link">
         <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
         </a>
         <!-- Sidebar -->
         <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
               <div class="image">
                  <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
               </div>
               <div class="info">
                  <a href="#" class="d-block"></a>
               </div>
            </div>
            <!-- Sidebar Menu -->
            <nav class="mt-2">
               <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                  <li class="nav-item">
                     <a href="BuyerDashboard.php" class="nav-link">
                        <i class="nav-icon fa fa-tachometer-alt"></i>
                        <p>
                           Dashboard
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Buyer_profile.php" class="nav-link">
                        <i class="nav-icon fa fa-users"></i>
                        <p>
                           Buyers Profile
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Buyer_Land_gallary.php" class="nav-link">
                        <i class="nav-icon fa fa-image"></i>
                        <p>
                           Land Gallary
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Owned_land.php" class="nav-link">
                        <i class="nav-icon fa fa-university"></i>
                        <p>
                           Search Lands
                        </p>
                     </a>
                  </li>
                  
                  
                  
               </ul>
            </nav>
            <!-- /.sidebar-menu -->
         </div>
         <!-- /.sidebar -->
      </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Land Gallary</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                              
                            <li class="breadcrumb-item"><a href="Owned_land.php">Search</a></li>
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Land Gallary</li>
                            </ol>
                        </div>
                        
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content --><br><br>
            
            <div class="site-section ">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-12 text-center">
            <h2 class="text-danger"><u>Recent Property</u></h2>
          </div>
        </div>
        <div class="row ">

        <table class="table table-striped table-dark">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Area name</th>
      <th scope="col">City</th>
      <th scope="col">State</th>
      <th scope="col">Area in sq feet</th>
      <th scope="col">Rate Per sq feet</th>
      <th scope="col">Price</th>
      <th scope="col">Property Image</th>
    </tr>
  </thead>
  <tbody>   
  <?php
include 'connect.php';
$pic = mysqli_query($con,"SELECT * FROM `land`");
while($row = mysqli_fetch_array($pic)){
echo "<tr>
<td>$row[id]</td>
<td>$row[aname]</td>
<td>$row[city]</td>
<td>$row[state]</td>
<td>$row[aisf]</td>
<td>$row[rpsf]</td>
<td>$row[price]</td>
<td><img src='$row[image]'  width = '200px'  height = '140px'></td>

<td></td>



</tr>
";
}

?>

       
    </tbody>
</table>
  <!-- /.content -->
            <!-- /.content -->
         </div>
        
        

              
        </div> 
    </div>
        </div> 
    </div>
    <!-- ./wrapper -->
    <!-- jQuery -->
    <script src="../asset/jquery/jquery.min.js"></script>
    <script src="../asset/js/adminlte.js"></script>

</body>

</html>