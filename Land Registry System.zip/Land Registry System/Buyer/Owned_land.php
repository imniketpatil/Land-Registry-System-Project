<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Buyer Profile</title>
   <!-- Font Awesome -->
   <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
   <link rel="stylesheet" href="../asset/css/adminlte.min.css">
   <link rel="stylesheet" href="../asset/css/style.css">
   <link rel="stylesheet" href="style2.css">
   <!-- Bootstrap 5 -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
   <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
         <!-- Right navbar links -->
         <ul class="navbar-nav ml-auto">

            <li class="nav-item">
               <a class="nav-link" data-widget="fullscreen" href="logout.php">
                  <i class="fas fa-power-off"></i>
               </a>
            </li>
         </ul>
      </nav>
      <!-- /.navbar -->
      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
         <!-- Brand Logo -->
         <a href="BuyerDashboard.html" class="brand-link">
            <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
         </a>
         <!-- Sidebar -->
         <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
               <div class="image">
                  <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
               </div>
               <div class="info">
                  <a href="#" class="d-block"></a>
               </div>
            </div>
            <!-- Sidebar Menu -->
            <nav class="mt-2">
               <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                  data-accordion="false">
                  <li class="nav-item">
                     <a href="BuyerDashboard.php" class="nav-link">
                        <i class="nav-icon fa fa-tachometer-alt"></i>
                        <p>
                           Dashboard
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Buyer_profile.php" class="nav-link">
                        <i class="nav-icon fa fa-users"></i>
                        <p>
                           Buyers Profile
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Buyer_Land_gallary.php" class="nav-link">
                        <i class="nav-icon fa fa-image"></i>
                        <p>
                           Land Gallary
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Owned_land.php" class="nav-link">
                        <i class="nav-icon fa fa-university"></i>
                        <p>
                           Search Lands
                        </p>
                     </a>
                  </li>



               </ul>
            </nav>
            <!-- /.sidebar-menu -->
         </div>
         <!-- /.sidebar -->
      </aside>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <div class="content-header">
            <div class="container-fluid">
               <div class="row mb-2">
                  <div class="col-sm-6">
                     <h1>Search Gallary</h1>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">
                     <ol class="breadcrumb float-sm-right">


                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Search Gallary</li>
                     </ol>
                  </div>

                  <!-- /.col -->
               </div>
               <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
         </div>
         <!-- /.content-header -->
         <!-- Main content --><br><br>
         <div class="row">
            <form class="" action="Owned_land.php" method="POST" autocomplete="off">
               <div class="col-md-12">
                  <div class="form-group">
                     <label for="aname"> Area name :</label>
                     <select name="aname">
                        <option> Select </option>
                        <option value="Manewada"> Manewada </option>
                        <option value="Mihan"> Mihan </option>
                        <option value=" Trimuti nagar "> Trimuti nagar </option>
                        <option value=" Somalwada "> Somalwada </option>
                        <option value=" Pratap nagar "> Pratap nagar </option>
                        <option value=" Laxmi nagar "> Laxmi nagar </option>
                        <option value=" Hingna "> Hingna </option>
                        <option value=" Digore"> Dighore </option>
                        <option value=" Dharampeth "> Dharampeth </option>
                        <option value=" Ramdaspeth "> Ramdaspeth </option>

                     </select>

                     <!-- <label for="city"> City :</label>
                                 <select name="city">
                                <option>  Select </option>
                                <option value="Nagpur"> Nagpur </option>
                                <option value=" Pune "> Pune </option>
                                <option value=" Mumbai "> Mumbai </option>
                                </select>
                                <label for="state">State :</label>
                                 <select name="state">
                                <option>  Select </option>
                                <option value="Maharashtra"> Maharashtra </option>
                                <option value=" Karnataka "> Karnataka </option>
                                <option value=" Madhya Pradesh "> Madhya Pradesh </option>
                                </select> -->
                     <label for="aisf"> Area(sq/ft) :</label>
                     <select name="aisf" required>
                        <option> Select </option>
                        <option value="600-999"> 600 to 999 </option>
                        <option value="1000-1199"> 1000 to 1199 </option>
                        <option value="1200-1499"> 1200 to 1499 </option>
                        <option value="1500-2000"> 1500 to 2000 </option>
                     </select>
                     <label for="rpsf">Rate(sq/ft)</label>
                     <select name="rpsf" required>
                        <option> Select </option>
                        <option value="1200-1500"> 1200-1500 </option>
                        <option value="1500-2000"> 1500-2000 </option>
                        <option value="2000-3000"> 2000-3000 </option>
                        <option value="3000-4000"> 3000-4000 </option>
                        <option value="4000-5000"> 4000-5000 </option>
                     </select>
                     <label for="price">Price :</label>
                     <select name="price" required>
                        <option> Select </option>
                        <option value="1000000-1500000"> 10 Lakh - 15 Lakh </option>
                        <option value="1500000-2000000"> 15 Lakh - 20 Lakh </option>
                        <option value="2000000-3000000"> 20 Lakh - 30 Lakh </option>
                        <option value="3000000-4000000"> 30 Lakh - 40 Lakh </option>
                        <option value="4000000-5000000"> 40 Lakh - 50 Lakh </option>
                        <option value="5000000-6000000"> 50 Lakh - 60 Lakh </option>
                        <option value="6000000-7000000"> 60 Lakh - 70 Lakh </option>
                     </select>

                     <button type="submit " name="submit">Search</button>

                  </div>

               </div>

            </form>
         </div>
         <div class="site-section ">
            <div class="container">
               <div class="row mb-5">
                  <div class="col-md-12 text-center">
                     <h2 class="text-danger"><u>Search Property</u></h2>
                  </div>
               </div>
               <div class="row ">

                  <table class="table table-striped table-dark">
                     <thead>
                        <tr>
                           <th scope="col">#ID</th>
                           <th scope="col">Area name</th>
                           <th scope="col">City</th>
                           <th scope="col">State</th>
                           <th scope="col">Area in sq feet</th>
                           <th scope="col">Rate Per sq feet</th>
                           <th scope="col">Price</th>
                           <th scope="col">Property Image</th>
                           <th>Request</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                        include('landsearch.php');
                        if (!isset($_POST['submit'])) {

                        } else {
                           $aname = $_POST['aname'];
                           // $city =$_POST['city'];
                           // $state =$_POST['state'];
                           $aisf = $_POST['aisf'];
                           $rpsf = $_POST['rpsf'];
                           $price = $_POST['price'];


                           if ($aname != "" || $city != "" || $state != "" || $aisf != "" || $rpsf != "" || $price != "") {


                              // For AREA range
                              $aisf_arr = explode('-', $aisf);
                              $min_aisf = $aisf_arr[0];
                              @$max_aisf = $aisf_arr[1];

                              // For price range
                              $rpsf_arr = explode('-', $rpsf);
                              $min_rpsf = $rpsf_arr[0];
                              @$max_rpsf = $rpsf_arr[1];

                              // For PRICE range
                              $price_arr = explode('-', $price);
                              $min_price = $price_arr[0];
                              @$max_price = $price_arr[1];

                              // SQL query
                              $query = "SELECT * FROM land WHERE aname = '$aname' OR aisf BETWEEN '$min_aisf' AND '$max_aisf' OR rpsf BETWEEN '$min_rpsf' AND '$max_rpsf' OR price BETWEEN '$min_price' AND '$max_price'";

                              $data = mysqli_query($conn, $query) or die('error');
                              if (mysqli_num_rows($data) > 0) {
                                 while ($row = mysqli_fetch_assoc($data)) {
                                    $id = $row['id'];
                                    $aname = $row['aname'];
                                    $city = $row['city'];
                                    $state = $row['state'];
                                    $aisf = $row['aisf'];
                                    $rpsf = $row['rpsf'];
                                    $price = $row['price'];
                                    $image = $row['image'];
                                    ?>
                                    
                                       <td></td>
                                       <td >
                                       </td>
                                    <tr>
                                       <td>
                                          <?php echo $id; ?>
                                       </td>
                                       <td>
                                          <?php echo $aname; ?>
                                       </td>
                                       <td>
                                          <?php echo $city; ?>
                                       </td>
                                       <td>
                                          <?php echo $state; ?>
                                       </td>
                                       <td>
                                          <?php echo $aisf; ?>
                                       </td>
                                       <td>
                                          <?php echo $rpsf; ?>
                                       </td>
                                       <td>
                                          <?php echo $price; ?>
                                       </td>
                                       <td><img src='<?php echo $image; ?>' width='200px' height='100px'></td>
                                       <td class="text-center">
                                          <a class="btn btn-sm btn-success" href="Land_Request.php"> Request Land</a>
                                       </td>
                                       <?php

                                 }
                              } else {
                                 ?>
                                 <tr>
                                    <td>No Records Found!</td>
                                 </tr>
                                 <?php


                              }
                           }
                        }
                        ?>
                     </tbody>
                  </table>
                  <!-- /.content -->
                  <!-- /.content -->
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- ./wrapper -->
   <!-- jQuery -->
   <script src="../asset/jquery/jquery.min.js"></script>
   <script src="../asset/js/adminlte.js"></script>

</body>

</html>