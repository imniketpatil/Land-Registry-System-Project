<?php
 
 session_start();
 include "config.php";
 if(isset($_POST['edit']))
 {
    $id=$_SESSION['id'];
    $name=$_POST['name'];
    $age=$_POST['age'];
    $city=$_POST['city'];
    $gender=$_POST['gender'];
    $contact=$_POST['contact'];
    $aadhar=$_POST['aadhar'];
    $email=$_POST['email'];
    $select= "select * from tb_blogin where id='$id'";
    $sql = mysqli_query($conn,$select);
    $row = mysqli_fetch_assoc($sql);
    $res= $row['id'];
    if($res === $id)
    {
   
       $update = "update tb_blogin set name='$name',age='$age',city='$city',gender='$gender',contact='$contact',aadhar='$aadhar',email='$email' where id='$id'";
       $sql2=mysqli_query($conn,$update);
if($sql2)
       { 
           /*Successful*/
           header('location:Buyer_profile.php');
       }
       else
       {
           /*sorry your profile is not update*/
           header('location:Buyer_profile.php');
       }
    }
    else
    {
        /*sorry your id is not match*/
        header('location:Buyer_profile.php');
    }
 }
?>