<?php 

    $con = mysqli_connect('localhost:3307','root','','addland');
    if(!$con)
    {
        echo ' Please Check Your Connection ';
    }


?>