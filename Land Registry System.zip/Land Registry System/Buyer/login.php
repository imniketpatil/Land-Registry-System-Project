<?php
require 'config.php';
if(!empty($_SESSION["id"])){
  header("Location: BuyerDashboard.php");
}
if(isset($_POST["submit"])){
  $usernameemail = $_POST["usernameemail"];
  $password = $_POST["password"];
  $result = mysqli_query($conn, "SELECT * FROM tb_blogin WHERE username = '$usernameemail' OR email = '$usernameemail'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
    if($password == $row['password']){
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      header("Location: BuyerDashboard.php");
    }
    else{
      echo
      "<script> alert('Wrong Password'); </script>";
    }
  }
  else{
    echo
    "<script> alert('User Not Registered'); </script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    
    <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="../asset/css/adminlte.min.css">
      <!-- css -->
      <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
      <link rel="stylesheet" href="style.css">
      <!-- Bootstrap 5 -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      <!-- js -->
      <script src="/asset/js/block.js"></script>
  </head>
  <body>
    <hr>
    <h1 class="text-danger animate__animated animate__slideOutDown animate__infinite	infinite">Buyer Login</h1>
    <hr>
    <hr>
    <hr><hr>
    <form class="box" method="post" autocomplete="off">
    <div class="row">
    <div class="col-md-12">
        <div class="form-group">
      <label for="usernameemail">Username or Email : </label><br>
      <input type="text" name="usernameemail" id = "usernameemail" required value=""> <br>
      </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
      <label for="password">Password : </label><br>
      <input type="password" name="password" id = "password" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
       <a href="registration.php">Create a New Account</a>
       </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
      <button type="submit" name="submit">Login</button>
      </div>
      </div>
    </form>
</div>


    <script src="../asset/jquery/jquery.min.js"></script>
      <script src="../asset/js/adminlte.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
