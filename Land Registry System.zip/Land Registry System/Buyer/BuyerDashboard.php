<?php
require 'config.php';
if(!empty($_SESSION["id"])){
  $id = $_SESSION["id"];
  $result = mysqli_query($conn, "SELECT * FROM tb_blogin WHERE id = $id");
  $row = mysqli_fetch_assoc($result);
}
else{
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Buyer Dashboard</title>
      <!-- Font Awesome -->
      <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="../asset/css/adminlte.min.css">
      <!-- css -->
      <link rel="stylesheet" href="../asset/css/style.css">
      <!-- Bootstrap 5 -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      <!-- js -->
      <script src="/asset/js/block.js"></script>

   </head>
   <body class="hold-transition sidebar-mini layout-fixed">
      <div class="wrapper">
         <!-- Navbar -->
         <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
               
               <li class="nav-item">
                 <a class="nav-link" data-widget="fullscreen" href="logout.php">
                  <i class="fas fa-power-off "></i>
                  </a>
               </li>
            </ul>
         </nav>
         <!-- /.navbar -->
         <!-- Main Sidebar Container -->
         <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
            <!-- Brand Logo -->
            <a href="/Buyer/BuyerDashboard.php" class="brand-link">
            <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
               <!-- Sidebar user panel (optional) -->
               <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                  <div class="image">
                     <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
                  </div>
                  <div class="info">
                     <a href="#" class="d-block"></a>
                  </div>
               </div>
               <!-- Sidebar Menu -->
               <nav class="mt-2">
                  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                     <li class="nav-item">
                        <a href="BuyerDashboard.php" class="nav-link">
                           <i class="nav-icon fa fa-tachometer-alt"></i>
                           <p>
                              Dashboard
                           </p>
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="Buyer_profile.php" class="nav-link">
                           <i class="nav-icon fa fa-users"></i>
                           <p>
                              Buyers Profile
                           </p>
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="Buyer_Land_gallary.php" class="nav-link">
                           <i class="nav-icon fa fa-image"></i>
                           <p>
                              Land Gallary
                           </p>
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="Owned_land.php" class="nav-link">
                           <i class="nav-icon fa fa-university"></i>
                           <p>
                              Search Lands
                           </p>
                        </a>
                     </li>
                     
                     
                  </ul>
               </nav>
               <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
         </aside>
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
               <div class="container-fluid">
                  <div class="row mb-2">
                     <div class="col-sm-6">
                        <h1 class="m-0"><span class="fa fa-tachometer-alt"></span> Dashboard</h1>
                     </div>
                     <!-- /.col -->
                     <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                           <li class="breadcrumb-item"><a href="#">Home</a></li>
                           <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                     </div>
                     <!-- /.col -->
                  </div>
                  <!-- /.row -->
               </div>
               <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <!-- <section class="content">
               <div class="container-fluid"> -->
                  <!-- Small boxes (Stat box) -->
                  <!-- <div class="row">
                     <div class="col-md-6 col-6"> -->
                        <!-- small box -->
                        <!-- <div class="small-box bg-1">
                           <div class="inner">
                              <h3>8</h3>
                              <p>Total Seller</p>
                           </div>
                           <div class="icon">
                              <i class="fa fa-book fa-2x"></i>
                           </div>
                           <a href="Buyer_profile.html" class="small-box-footer">View Profile<i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                     </div> -->
                     <!-- ./col -->
                     <!-- <div class="col-md-6 col-6"> -->
                        <!-- small box -->
                        <!-- <div class="small-box bg-info">
                           <div class="inner">
                              <h3>4</h3>
                              <p>Registered Lands Count</p>
                           </div>
                           <div class="icon">
                              <i class="fa fa-bell fa-2x"></i>
                           </div>
                           <a href="Buyer_Land_gallary.html" class="small-box-footer">View Your Lands <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                     </div>
                     <div class="col-md-4 col-6"> -->
                        <!-- small box -->
                        
                     <!-- </div>
                  </div> -->
                  <!-- /.row -->
                  <!-- /.row (main row) -->
               <!-- </div> -->
               <!-- /.container-fluid -->
            <!-- </section> -->
            <!-- /.content -->
            <!-- Main content -->
            <!-- Main content -->
            <table class="table table-striped table-dark">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Area name</th>
      <th scope="col">City</th>
      <th scope="col">State</th>
      <th scope="col">Area in sq feet</th>
      <th scope="col">Rate Per sq feet</th>
      <th scope="col">Price</th>
      <th scope="col">Property Image</th>
    </tr>
  </thead>
  <tbody>   
  <?php
include 'connect.php';
$pic = mysqli_query($con,"SELECT * FROM `land`");
while($row = mysqli_fetch_array($pic)){
echo "<tr>
<td>$row[id]</td>
<td>$row[aname]</td>
<td>$row[city]</td>
<td>$row[state]</td>
<td>$row[aisf]</td>
<td>$row[rpsf]</td>
<td>$row[price]</td>
<td><img src='$row[image]'  width = '200px'  height = '140px'></td>

<td></td>



</tr>
";
}

?>

       
    </tbody>
</table>
               <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
      </div>
      <!-- ./wrapper -->
      
      <!-- jQuery -->
      <script src="../asset/jquery/jquery.min.js"></script>
      <script src="../asset/js/adminlte.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   </body>
</html>