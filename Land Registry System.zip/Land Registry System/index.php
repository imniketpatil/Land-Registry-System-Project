
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E-PROPERTY CLINIC</title>


<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">

<!-- Stylesheet
    ================================================== -->
<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <div class="navbar-header">
      <a href="#header"><img src="whitelogo.png" alt="" width="214.96875px" height="51.875px"></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    </div>
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#services" class="page-scroll">Services</a></li>
        <li><a href="#portfolio" class="page-scroll">Projects</a></li>
        <li><a href="#footer" class="page-scroll">Contact</a></li>
        <li><a href="rolelogin.php" class="page-scroll">LOGIN</a></li>
      </ul>
    </div>
     
  </div>
</nav>

<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>Healty Property For Healty Future</h1>
            <p>Its crystal clear, we aim to be the corporate brand having value for time & money,safe & secure future of healthy property for our family members. In this pathway of progress, we take care to nurture the nature for our beloved earth planet.</p>
        </div>
      </div>
    </div>
  </div>
</header>


<div id="about">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6"> <iframe width="450" height="315" src="https://www.youtube.com/embed/j02Y07T2sjo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
          <h2>Welcome to Property Clinic</h2>
          <p>Property Clinic brings the philosophy of innovation, sustainability and excellence to the real estate industry with their young and dynamic promoter Mr.Lochan Meera. Established in 2019, Property Clinic is the first real estate company fulfilling and working for property needs of Common men to Elite Class. Each promoter’s expertise in Real Estate Industry combines more than 36year legacy of excellence and trust with a commitment to cutting-edge design and technology.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Services</h2>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="service-media"> <img src="consultancy-icon-15670.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Real Estate Consultancy</h3>
        </div>
      </div>
      <div class="col-md-3">
        <div class="service-media"> <img src="5016212.png" alt=" "> </div>
        <div class="service-desc">
          <h3>Real Estate Sales & Marketing</h3>
        </div>
      </div>
      <div class="col-md-3">
        <div class="service-media"> <img src="road-map-icon.png" alt=" "> </div>
        <div class="service-desc">
          <h3>Real Estate Road Map</h3>
        </div>
      </div>
      <div class="col-md-3">
        <div class="service-media"> <img src="kissclipart-videoconference-icon-clipart-computer-icons-videot-56de5f8740d3d676.png" alt=" "> </div>
        <div class="service-desc">
          <h3>Real Estate Awareness Program</h3>
        </div>
      </div>
    </div>
    
      </div>
    </div>
  </div>
</div>

<div id="portfolio">
  <div class="container">
    <div class="section-title">
      <h2>Projects</h2>
    </div>
    <div class="row">
      <div class="portfolio-items">
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg">
              <div class="hover-text">
                <h4>Royal Rajgad</h4>
              </div>
              <img src="RR.png" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg">
              <div class="hover-text">
                <h4>Mulshi Hill</h4>
              </div>
              <img src="mul.png" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg">
              <div class="hover-text">
                <h4>Nisarg Srishti</h4>
              </div>
              <img src="nis.png" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="footer">

  <div class="container">
    <div class="col-md-8">
      <div class="row">
        <div class="section-title">
          <h2>Contact Us</h2>
        </div>
        <form action="contact.php" method="post">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <input type="text"name="name" id="name" class="form-control" placeholder="Name" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <input type="email" name="email" id="email" class="form-control" placeholder="Email" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
          </div>
          <div class="form-group">
            <textarea name="message" name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
            <p class="help-block text-danger"></p>
          </div>
          <div id="success"></div>
          <button type="submit" class="btn btn-custom btn-lg">Send Message</button>
        </form>
      </div>
    </div>
    <div class="col-md-3 col-md-offset-1 contact-info">
      <div class="contact-item">
        <h4>Contact Info</h4>
        <p><span>Address</span>Milestone Building, Ramdaspeth, Nagpur, Maharashtra 440010</p>
      </div>
      <div class="contact-item">
        <p><span>Phone</span>+91 99230 44520</p>
      </div>
      <div class="contact-item">
        <p><span>Email</span>info@epropertyclinic.com</p>
      </div>
    </div>
    <div class="col-md-12">
      <div class="row">
        <div class="social">
          <ul>
            <li>  <a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.facebook.com/epropertyclinic/?modal=admin_todo_tour" role="button"
              data-mdb-ripple-color="dark"><i><img src="https://img.icons8.com/ios-glyphs/30/000000/facebook-new.png"/></i></a></i></a></li>
            <li><a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://twitter.com/clinic_property" role="button"
              data-mdb-ripple-color="dark"><i><img src="https://img.icons8.com/ios-glyphs/30/000000/twitter--v1.png"/></i>
            </a></li>
            <li><a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.instagram.com/eproperty_clinic/" role="button"
              data-mdb-ripple-color="dark"><i><img src="https://img.icons8.com/ios-glyphs/30/000000/instagram-new.png"/></i></a></li>
            <li><a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.youtube.com/channel/UCsn7o0uL595gKQll9oN05Kw?view_as=subscriber" role="button"
              data-mdb-ripple-color="dark"><i><img src="https://img.icons8.com/ios-glyphs/30/000000/youtube-play.png"/></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>