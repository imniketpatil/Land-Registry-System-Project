<?php

$Name = $_POST["name"];
$Email = $_POST["email"];
$Message= $_POST["message"];
$conn = mysqli_connect("localhost", "root", "", "epropertyclinic") or die("connection failed");
$sql ="INSERT INTO contact(name, email, message) VALUES ('{$Name}','{$Email}','{$Message}')";
$result = mysqli_query($conn, $sql) or die("query failed");
header("location: http://localhost/Land%20Registry%20System/");
mysqli_close($conn);
?>