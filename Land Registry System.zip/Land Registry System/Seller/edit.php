<?php
include 'config.php';
$id=$_GET['id'];
$select="SELECT * FROM tb_slogin WHERE id='$id'";
$select_q=mysqli_query($con,$select);
$fetch=mysqli_fetch_array($select_q);
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Seller Profile</title>
   <!-- Font Awesome -->
   <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
   <link rel="stylesheet" href="../asset/css/adminlte.min.css">
   <link rel="stylesheet" href="../asset/css/style.css">
   <!-- Bootstrap 5 -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
   <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
         <!-- Right navbar links -->
         <ul class="navbar-nav ml-auto">
            <li class="nav-item">
               <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                  <i class="fas fa-expand-arrows-alt"></i>
               </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" data-widget="fullscreen" href="logout.php">
                  <i class="fas fa-power-off"></i>
               </a>
            </li>
         </ul>
      </nav>
      <!-- /.navbar -->
      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
         <!-- Brand Logo -->
         <a href="#" class="brand-link">
         <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
         </a>
         <!-- Sidebar -->
         <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
               <div class="image">
                  <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
               </div>
               <div class="info">
                  <a href="#" class="d-block"><?php echo $row["name"];?></a>
               </div>
            </div>
            <!-- Sidebar Menu -->
            <nav class="mt-2">
               <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                  <li class="nav-item">
                     <a href="SellerDashboard.html" class="nav-link">
                        <i class="nav-icon fa fa-tachometer-alt"></i>
                        <p>
                           Dashboard
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Add_land.html" class="nav-link">
                        <i class="nav-icon fa fa-globe"></i>
                        <p>
                           Add Land
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Seller_profile.html" class="nav-link">
                        <i class="nav-icon fa fa-user"></i>
                        <p>
                           Seller Profile
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="Land_request.html" class="nav-link">
                        <i class="nav-icon fa fa-id-card"></i>
                        <p>
                           Land Requests
                        </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-question-circle"></i>
                        <p>
                           Help
                        </p>
                     </a>
                  </li>
                  
               </ul>
            </nav>
            <!-- /.sidebar-menu -->
         </div>
         <!-- /.sidebar -->
      </aside>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <div class="content-header">
            <div class="container-fluid">
               <div class="row mb-2">
                  <div class="col-sm-6">
                     <h1>Seller Profile</h1>
                     <h7 style="color:blue;" class="m-0" >Not yet Verified<span class="fa fa-user-cog"></span></h7>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">
                     <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Profile</li>
                     </ol>
                  </div>
                  <!-- /.col -->
               </div>
               <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
         </div>
         <!-- /.content-header -->
         <!-- Main content -->
         <section class="content">
            <div class="container-fluid">
               <div class="card card-info">
                  <div class="card-header">
                     <h3 class="card-title">Seller Profile</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form class="" action="" method="post" >
                     <div class="card-body">
                        <div class="row">
                           
                           <div class="row">
                              
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" id = "name" placeholder="<?php echo $row["name"];?>" >
                                 </div>
                              </div>
                              
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Age</label>
                                    <input type="text" class="form-control"  name="age" id = "age" placeholder="<?php echo $row["age"];?>" >
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>City</label>
                                    <input type="text" class="form-control" name="city" id = "city"  placeholder="<?php echo $row["city"];?>" >
                                 </div>
                                 <div class="col-md-12">
                                 <div class="form-group">
                                 <label for="gender">Enter Gender :</label><br>
                                 <select name="gender">
                                 <option value=""><?php echo $row["gender"];?></option>
                                 <option value="Male"> Male </option>
                                 <option value="Female"> Female </option>
                                  </select>
                                 </div>
                                 </div>
                                 <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Contact</label>
                                    <input type="number" class="form-control" name="contact" id = "contact" placeholder="<?php echo $row["contact"];?>">
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Aadhar Number</label>
                                    <input type="number" class="form-control" name="aadhar" id = "aadhar" placeholder="<?php echo $row["aadhar"];?>" >
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="email" class="form-control" name="email" id = "email" placeholder="<?php echo $row["email"];?>" >
                                 </div>
                              </div>
                              
                              </div>
                              
                              
                              
                           </div>
                        </div>
                     </div>

               </div>
               <!-- /.card-body -->

               <div class="card-footer">
               <a href="Seller_profile.php ?id=<?php echo $row['id'] ?>"> <button type="submit" name="edit" class="btn btn-primary">Edit Profile</button></a>
               </div>
               </form>
               <?php
               if(isset($_POST["edit"])){
                  $name = $_POST["name"];
                  $age = $_POST["age"];
                  $city = $_POST["city"];
                  $gender = $_POST["gender"];
                  $contact = $_POST["contact"];
                  $aadhar = $_POST["aadhar"];
                  $email = $_POST["email"];
               {
                      $update="UPDATE tb_slogin SET name='$name',age='$age',city='$city',gender='$gender',contact='$contact',aadhar='$aadhar',email='$email'
                      Where id='$id'";
                      $update_q=mysqli_query($con,$update);
                      header('location:registration.php');
               }
               }
               ?>
            </div>
      </div>
      <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
   </div>
   <!-- /.content-wrapper -->
   </div>
   <!-- ./wrapper -->
   <!-- jQuery -->
   <script src="../asset/jquery/jquery.min.js"></script>
   <script src="../asset/js/adminlte.js"></script>

</body>

</html>