<?php

$Areaname = $_POST["areaname"];
$City = $_POST["city"];
$State= $_POST["state"];
$Area = $_POST["area"];
$Rate = $_POST["rate"];
$Price = $_POST["price"];
$conn = mysqli_connect("localhost", "root", "", "addland") or die("connection failed");
$sql ="INSERT INTO land(areaname, city, state, area, rate, price) VALUES ('{$Areaname}','{$City}','{$State}','{$Area}','{$Rate}','{$Price}')";
$result = mysqli_query($conn, $sql) or die("query failed");
header("location: http://localhost/Land%20Registry%20System/Seller/Add_land.php");
mysqli_close($conn);
?>