<?php
// include db connection
include 'connect.php';

if(isset($_POST['upload'])){
    $aname = $_POST['aname'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $aisf = $_POST['aisf'];
    $rpsf = $_POST['rpsf'];
    $price = $_POST['price'];
    $IMAGE = $_FILES['image'];
    $img_loc = $_FILES['image']['tmp_name'];
    $img_name = $_FILES['image']['name'];
    $img_des = "uploadImage/".$img_name;
    move_uploaded_file($img_loc,'uploadImage/'.$img_name);
    $Verif=$_POST['sellerverify'];

    // insert data

    mysqli_query($con,"INSERT INTO `land`( `aname`,`city`,`state`,`aisf`,`rpsf`, `price`, `Image`) VALUES ('$aname','$city','$state','$aisf','$rpsf','$price','$img_des')");
    header("location:SellerDashboard.php");

}

?>