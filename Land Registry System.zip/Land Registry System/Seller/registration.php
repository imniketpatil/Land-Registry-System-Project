<?php
require 'config.php';
if(!empty($_SESSION["id"])){
  header("Location: SellerDashboard.php");
}
if(isset($_POST["submit"])){
  $name = $_POST["name"];
  $age = $_POST["age"];
  $city = $_POST["city"];
  $gender = $_POST["gender"];
  $contact = $_POST["contact"];
  $aadhar = $_POST["aadhar"];
  $username = $_POST["username"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $confirmpassword = $_POST["confirmpassword"];
  $duplicate = mysqli_query($conn, "SELECT * FROM tb_slogin WHERE username = '$username' OR email = '$email'");
  if(mysqli_num_rows($duplicate) > 0){
    echo
    "<script> alert('Username or Email Has Already Taken'); </script>";
  }
  else{
    if($password == $confirmpassword){
      $query = "INSERT INTO tb_slogin VALUES('','$name','$age','$city','$gender','$contact','$aadhar','$username','$email','$password')";
      mysqli_query($conn, $query);
      echo
      "<script> alert('Registration Successful'); </script>";
    }
    else{
      echo
      "<script> alert('Password Does Not Match'); </script>";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Registration</title>
    <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="../asset/css/adminlte.min.css">
      <!-- css -->
      <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
      <link rel="stylesheet" href="style.css">
      <!-- Bootstrap 5 -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      <!-- js -->
      <script src="/asset/js/block.js"></script>
  </head>
  <body>
    <h2 class="text-danger animate__animated animate__slideOutDown animate__infinite	infinite"> Seller Registration</h2></div>
  <hr><hr>
    <form class="" action="" method="post" autocomplete="off">
    <div class="row">
      <div class="col-md-6">
      <div class="form-group">
      <label for="name">Name : </label>
      <input type="text" class="txt"name="name" id = "name" required value="">
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="age">Enter Age :</label>
          <input type="number" class="num" name="age" id = "age" required value="">
        </div>
      </div>
      <div class="col-md-6">
      <div class="form-group">
      <label for="name">Enter City : </label>
      <input type="text" class="txt"name="city" id = "city" required value="">
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="gender">Enter Gender :</label><br>
          <select name="gender" required>
            <option value="" required>--Select--</option>
            <option value="Male"> Male </option>
            <option value="Female"> Female </option>
         </select>
         
        </div>
      </div>
      <div class="col-md-6">
      <div class="form-group">
      <label for="contact">Contact No: </label>
      <input type="phone" name="contact" id = "contact" minlength="10" maxlength="10" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
      <label for="aadhar">Aadhar No : </label>
      <input type="number" name="aadhar" id = "aadhar" min="100000000000" max="999999999999" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
      <div class="form-group">
      <label for="username">Username : </label>
      <input type="text" name="username" id = "username" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
      <label for="email">Email : </label>
      <input type="email" name="email" id = "email" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
      <label for="password">Password : </label>
      <input type="password" name="password" id = "password" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
      <label for="confirmpassword">Confirm Password : </label>
      <input type="password" name="confirmpassword" id = "confirmpassword" required value=""> <br>
      </div>
      </div>
      <div class="col-md-6">
        <div class="form-group text-center">
       <a href="login.php">  Login</a>
       </div>
      </div>
      <div class="col-md-6 ">
        <div class="form-group text-center ">
      <button type="submit " name="submit" >Register</button>
      </div>
      </div>
      
    </form>

    <script src="../asset/jquery/jquery.min.js"></script>
      <script src="../asset/js/adminlte.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
