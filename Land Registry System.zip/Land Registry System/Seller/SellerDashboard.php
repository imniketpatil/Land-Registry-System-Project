

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Seller Dashboard</title>
      <!-- Font Awesome -->
      <link rel="stylesheet" href="../asset/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="../asset/css/adminlte.min.css">
      <link rel="stylesheet" href="../asset/css/style.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/web3@latest/dist/web3.min.js"></script>
      <script src="/asset/js/block.js"></script>

      <!-- Bootstrap 5 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   </head>
   <body class="hold-transition sidebar-mini layout-fixed">
      <div class="wrapper">
         <!-- Navbar -->
         <!-- Right navbar links -->
         <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav ml-auto">
               
               <li class="nav-item">
                  <a class="nav-link"  onclick="connect()" data-widget="fullscreen" href="logout.php">
                  <i class="fas fa-power-off"></i>
                  </a>
               </li>
            </ul>
         </nav>
         <!-- /.navbar -->
         <!-- Main Sidebar Container -->
         <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: rgba(62,88,113);">
            <!-- Brand Logo -->
            <a href="#" class="brand-link">
            <img src="../asset/img/logo1.png" alt="DSMS Logo" width="200">
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
               <!-- Sidebar user panel (optional) -->
               <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                  <div class="image">
                     <img src="../asset/img/avatar.jpg" class="img-circle elevation-2" alt="User Image">
                  </div>
                  <div class="info">
                     <a href="#" class="d-block"></a>
                  </div>
               </div>
               <!-- Sidebar Menu -->
               <nav class="mt-2">
                  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                     <li class="nav-item">
                        <a href="SellerDashboard.php" class="nav-link">
                           <i class="nav-icon fa fa-tachometer-alt"></i>
                           <p>
                              Add Land
                           </p>
                        </a>
                     </li>
                     <li class="nav-item">
                        <a href="Seller_profile.php" class="nav-link">
                           <i class="nav-icon fa fa-user"></i>
                           <p>
                              Seller Profile
                           </p>
                        </a>
                     </li>
                     
                     
                  </ul>
               </nav>
               <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
         </aside>
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <div class="content-header">
            <div class="container-fluid">
               <div class="row mb-2">
                  <div class="col-sm-6">
                     <h1 class="m-0"><span class="fa fa-globe"></span> Add Land</h1>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">
                     <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Add Land</li>
                     </ol>
                  </div>
                  <!-- /.col -->
               </div>
               <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
         </div>
         <!-- /.content-header -->
         <!-- Main content -->
         <section class="content">
            <div class="container-fluid">
               <div class="card card-info">
                  <div class="card-header">
                     <h3 class="card-title">Add Land</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form action="insert.php" method="POST" enctype="multipart/form-data" >
                     <div class="card-body">
                        <div class="row">
                           
                           <div class="row">
                              
                              <div class="col-md-12">
                                 <div class="form-group">
                                 <label for="aname"> Area name :</label>
                                <select name="aname" require>
                                <option require>  Select </option>
                                <option value="Manewada"> Manewada </option>
                                <option value="Mihan"> Mihan </option>
                                <option value=" Trimuti nagar "> Trimuti nagar </option>
                                <option value=" Somalwada "> Somalwada </option>
                                <option value=" Pratap nagar "> Pratap nagar </option>
                                <option value=" Laxmi nagar "> Laxmi nagar </option>
                                <option value=" Hingna "> Hingna </option>
                                <option value=" Digore"> Dighore </option>
                                <option value=" Dharampeth "> Dharampeth </option>
                                <option value=" Ramdaspeth "> Ramdaspeth </option>
                                
                                 </select>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>City</label>
                                    <input type="text" name="city" class="form-control" require >
                                 </div>
                              </div>
                              
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>State</label>
                                    <input type="text"name="state" class="form-control" require>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Area(in sqft.)</label>
                                    <input type="number" name="aisf"class="form-control" require>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Rate Per sq feet</label>
                                    <input type="number"name="rpsf" class="form-control" require>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label>Price</label>
                                    <input type="number"name="price" class="form-control" require>
                                 </div>
                              </div>
                              
                              <!-- <div class="col-md-12">
                                 <div class="form-group">
                                 <label for="sellerverify">Document And Verification</label><br>
          <select name="sellerverify">
            <option value="">--Select--</option>
            <option value="Not Verified"> Not Verified </option>
            <option value="Verified"> Done And Verified </option>
            
         </select>
                                 </div>
                              </div> -->

                              
                              
                              <div class="col-md-12">
                                 
                                    <div class="form-group">
                                      <label for="exampleFormControlFile1">Insert Land Image</label>
                                      <input type="file" name="image" class="form-control-file" id="exampleFormControlFile1" require>
                                    </div>
                                  
                              </div>
                           </div>
                        </div>
                     </div>

               </div>
               <!-- /.card-body -->

               <div class="card-footer">
                  <button type="submit" name="upload"class="btn btn-primary">Add Land</button>
               </div>
               </form>
            </div>
      </div>
      <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
   </div>
               <!-- /.container-fluid -->
            <!-- </section> -->
            <!-- /.content -->
            <!-- Main content -->
            <!-- Main content -->
            
</tbody>
</table>
            <!-- /.content -->
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
      </div>
      <!-- ./wrapper -->
      
      <!-- jQuery -->
      <script src="../asset/jquery/jquery.min.js"></script>
      <script src="../asset/js/adminlte.js"></script>
      <script src="/asset/js/bootstrap.bundle.min.js" ></script>
      <script src="/asset/js/canvasjs.min.js" ></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
   </body>
</html>