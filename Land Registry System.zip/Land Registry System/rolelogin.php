<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Land Registry System</title>
      <!-- Google Font: Source Sans Pro -->
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="asset/fontawesome/css/all.min.css">
      <!-- Theme style -->
      <link rel="stylesheet" href="asset/css/adminlte.min.css">
      <!-- Bootstrap 5 -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <!-- js -->
      <script>
         function goToNewPage(src) {
            //  var url = document.getElementById("list").value;
            //  console.log(url);
            window.location=src;
         }
     </script>
     
   </head>
   <body class="hold-transition login-page bg-grey">
      <a href="index.php"><img src="asset/img/arrow.png"></a>
      <div class="login-box">
         <!-- /.login-logo -->
         <div class="card card-outline card-primary">
            <div class="text-center">
               <a href="index.php" class="brand-link">
               <img src="asset/img/logo1.png" alt="DSMS Logo" width="200">
               </a>
            </div>
            <div class="text-center">
               <h2>Welcome!</h2>
               <h4>Making Most of Digital Era!</h2>
            </div>
            <div class="card-body">
               <form action="admin" name="dropdown">
                  <div class="input-group mb-3"> 
                     <select class="form-control" id="list" onchange="goToNewPage(this.value)">
                        <option selected>Select Role</option>
                        <option value="Buyer/login.php">Buyer</a></option>
                        <option value="Seller/login.php">Seller</option>
                        <option value="admin/login.php">Admin</option>
                      </select>                         
                  </div>
                  <div class="col-12">
                     <option value="select" class="btn btn-info btn-block" onclick="goToNewPage">Choose Role</button> 
                   </div>
               </form>
            </div>
            <!-- /.card-body -->
         </div>
         <!-- /.card -->
      </div>
      <!-- /.login-box -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   </body>
</html>