-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 09:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `addland`
--

-- --------------------------------------------------------

--
-- Table structure for table `land`
--

CREATE TABLE `land` (
  `id` int(250) NOT NULL,
  `aname` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `aisf` int(250) NOT NULL,
  `rpsf` int(250) NOT NULL,
  `price` int(250) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `land`
--

INSERT INTO `land` (`id`, `aname`, `city`, `state`, `aisf`, `rpsf`, `price`, `image`) VALUES
(3, 'Manewada', 'Nagpur', 'Maharashtra', 1100, 2000, 2200000, 'uploadImage/1.jpeg'),
(4, 'Manewada', 'Nagpur', 'Maharashtra', 1070, 1000, 1070000, 'uploadImage/2.jpg'),
(5, 'Manewada', 'Nagpur', 'Maharashtra', 1500, 3930, 5895000, 'uploadImage/3.jpg'),
(6, 'Manewada', 'Nagpur', 'Maharashtra', 1750, 3830, 6702500, 'uploadImage/4.jpg'),
(7, 'Manewada', 'Nagpur', 'Maharashtra', 2800, 2142, 6000000, 'uploadImage/6.jpg'),
(8, 'Manewada', 'Nagpur', 'Maharashtra', 3000, 1500, 4500000, 'uploadImage/8.jpg'),
(9, 'Manewada', 'Nagpur', 'Maharashtra', 2857, 1750, 5000000, 'uploadImage/9.jpg'),
(10, 'Manewada', 'Nagpur', 'Maharashtra', 4200, 7142, 30000000, 'uploadImage/12.jpg'),
(11, 'Manewada', 'Nagpur', 'Maharashtra', 2100, 3000, 6300000, 'uploadImage/13.jpg'),
(12, 'Mihan', 'Nagpur', 'Maharashtra', 1000, 1000, 1000000, 'uploadImage/15.jpg'),
(13, 'Mihan', 'Nagpur', 'Maharashtra', 1850, 1351, 2500000, 'uploadImage/17.jpg'),
(14, 'Mihan', 'Nagpur', 'Maharashtra', 1260, 1525, 1921000, 'uploadImage/18.jpg'),
(15, 'Mihan', 'Nagpur', 'Maharashtra', 1100, 1000, 1100000, 'uploadImage/19.jpg'),
(16, 'Mihan', 'Nagpur', 'Maharashtra', 1500, 1000, 1500000, 'uploadImage/20.jpg'),
(17, 'Manewada', 'Nagpur', 'Maharashtra', 1500, 4700, 7000000, 'uploadImage/blankproperty.jpg'),
(18, 'Manewada', 'Nagpur', 'Maharashtra', 1575, 4507, 7000000, 'uploadImage/blankproperty.jpg'),
(19, 'Mihan', 'Nagpur', 'Maharashtra', 1453, 1000, 1453000, 'uploadImage/21.jpg'),
(20, 'Mihan', 'Nagpur', 'Maharashtra', 2500, 1525, 3900000, 'uploadImage/22.jpg'),
(21, 'Mihan', 'Nagpur', 'Maharashtra', 1800, 1525, 2745000, 'uploadImage/23.jpg'),
(22, 'Mihan', 'Nagpur', 'Maharashtra', 2273, 1550, 3523000, 'uploadImage/blankproperty.jpg'),
(23, 'Mihan', 'Nagpur', 'Maharashtra', 1500, 1525, 2288000, 'uploadImage/24.jpg'),
(24, 'Mihan', 'Nagpur', 'Maharashtra', 1200, 1525, 1800000, 'uploadImage/25.jpg'),
(25, 'Mihan', 'Nagpur', 'Maharashtra', 1650, 1300, 2200000, 'uploadImage/26.jpg'),
(26, 'Mihan', 'Nagpur', 'Maharashtra', 2000, 1375, 2750000, 'uploadImage/27.jpg'),
(27, 'Mihan', 'Nagpur', 'Maharashtra', 1500, 1380, 2007000, 'uploadImage/28.jpg'),
(28, 'Pratap nagar', 'Nagpur', 'Maharashtra', 3000, 6000, 18000000, 'uploadImage/blankproperty.jpg'),
(29, 'Pratap nagar', 'Nagpur', 'Maharashtra', 1800, 6666, 10200000, 'uploadImage/blankproperty.jpg'),
(30, 'Pratap nagar', 'Nagpur', 'Maharashtra', 3000, 10500, 31500000, 'uploadImage/31.jpg'),
(31, 'Pratap nagar', 'Nagpur', 'Maharashtra', 1500, 6333, 9500000, 'uploadImage/32.jpg'),
(32, 'Pratap nagar', 'Nagpur', 'Maharashtra', 4800, 12500, 60000000, 'uploadImage/33.jpg'),
(33, 'Pratap nagar', 'Nagpur', 'Maharashtra', 1750, 8571, 10500000, 'uploadImage/blankproperty.jpg'),
(34, 'Pratap nagar', 'Nagpur', 'Maharashtra', 1800, 10277, 18500000, 'uploadImage/blankproperty.jpg'),
(35, 'Ramdaspeth', 'Nagpur', 'Maharashtra', 2600, 12000, 31200000, 'uploadImage/36.jpg'),
(36, 'Ramdaspeth', 'Nagpur', 'Maharashtra', 4941, 12002, 59300000, 'uploadImage/37.jpg'),
(37, 'Ramdaspeth', 'Nagpur', 'Maharashtra', 2400, 9791, 23500000, 'uploadImage/blankproperty.jpg'),
(38, 'Hingna', 'Nagpur', 'Maharashtra', 1500, 1890, 2835000, 'uploadImage/39.jpg'),
(39, 'Hingna', 'Nagpur', 'Maharashtra', 1600, 1200, 1900000, 'uploadImage/40.jpg'),
(40, 'Hingna', 'Nagpur', 'Maharashtra', 1200, 1625, 1950000, 'uploadImage/41.jpg'),
(41, 'Mihan', 'Nagpur', 'Maharashtra', 1500, 1600, 2400000, 'uploadImage/42.jpg'),
(42, 'Hingna', 'Nagpur', 'Maharashtra', 1326, 904, 1200000, 'uploadImage/43.jpg'),
(43, 'Hingna', 'Nagpur', 'Maharashtra', 2000, 800, 1600000, 'uploadImage/44.jpg'),
(44, 'Hingna', 'Nagpur', 'Maharashtra', 1500, 1300, 1950000, 'uploadImage/45.jpg'),
(45, 'Hingna', 'Nagpur', 'Maharashtra', 1205, 1650, 1988000, 'uploadImage/46.jpg'),
(46, 'Hingna', 'Nagpur', 'Maharashtra', 1377, 1799, 2480000, 'uploadImage/47.jpg'),
(47, 'Hingna', 'Nagpur', 'Maharashtra', 1200, 1850, 2220000, 'uploadImage/48.jpg'),
(48, 'Hingna', 'Nagpur', 'Maharashtra', 1404, 1848, 2595000, 'uploadImage/49.jpg'),
(49, 'Hingna', 'Nagpur', 'Maharashtra', 1403, 1849, 2595000, 'uploadImage/50.jpg'),
(50, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1750, 5714, 10000000, 'uploadImage/blankproperty.jpg'),
(51, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1800, 5555, 10000000, 'uploadImage/52.jpg'),
(52, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1500, 6333, 9500000, 'uploadImage/53.jpg'),
(53, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1800, 6500, 11700000, 'uploadImage/54.jpg'),
(54, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 3000, 6500, 19500000, 'uploadImage/blankproperty.jpg'),
(55, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 600, 6833, 4100000, 'uploadImage/56.jpg'),
(56, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1750, 5714, 10000000, 'uploadImage/57.jpg'),
(57, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1840, 6793, 12300000, 'uploadImage/58.jpg'),
(58, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1500, 7666, 11500000, 'uploadImage/59.jpg'),
(59, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1800, 4444, 8000000, 'uploadImage/60.jpg'),
(60, 'Trimurti nagar', 'Nagpur', 'Maharashtra', 1500, 7333, 11000000, 'uploadImage/61.jpg'),
(61, 'Gorewada', 'Nagpur', 'Maharashtra', 1500, 2500, 3750000, 'uploadImage/62.jpg'),
(62, 'Gorewada', 'Nagpur', 'Maharashtra', 1500, 2260, 3390000, 'uploadImage/63.jpg'),
(63, 'Gorewada', 'Nagpur', 'Maharashtra', 1200, 2166, 2600000, 'uploadImage/64.jpg'),
(64, 'Gorewada', 'Nagpur', 'Maharashtra', 1500, 3333, 5000000, 'uploadImage/65.jpg'),
(65, 'Gorewada', 'Nagpur', 'Maharashtra', 1500, 2333, 3500000, 'uploadImage/66.jpg'),
(66, 'Gorewada', 'Nagpur', 'Maharashtra', 3000, 1666, 5000000, 'uploadImage/67.jpg'),
(67, 'Gorewada', 'Nagpur', 'Maharashtra', 2350, 1446, 3400000, 'uploadImage/68.jpg'),
(68, 'Dighori', 'Nagpur', 'Maharashtra', 1500, 1600, 2400000, 'uploadImage/69.jpg'),
(69, 'Dighori', 'Nagpur', 'Maharashtra', 2000, 2750, 5500000, 'uploadImage/70.jpg'),
(70, 'Dighori', 'Nagpur', 'Maharashtra', 760, 3003, 2283000, 'uploadImage/71.jpg'),
(71, 'Dighori', 'Nagpur', 'Maharashtra', 1500, 2666, 4000000, 'uploadImage/72.jpg'),
(72, 'Dighori', 'Nagpur', 'Maharashtra', 1680, 3095, 5200000, 'uploadImage/73.jpg'),
(73, 'Dighori', 'Nagpur', 'Maharashtra', 1000, 2450, 2450000, 'uploadImage/74.jpg'),
(74, 'Manish nagar', 'Nagpur', 'Maharashtra', 1452, 4407, 6400000, 'uploadImage/75.jpg'),
(75, 'Manish nagar', 'Nagpur', 'Maharashtra', 1000, 3200, 3200000, 'uploadImage/76.jpg'),
(76, 'Manish nagar', 'Nagpur', 'Maharashtra', 1753, 3993, 7000000, 'uploadImage/77.jpg'),
(77, 'Manish nagar', 'Nagpur', 'Maharashtra', 1284, 3250, 4173000, 'uploadImage/78.jpg'),
(78, 'Manish nagar', 'Nagpur', 'Maharashtra', 2100, 4500, 9450000, 'uploadImage/79.jpg'),
(79, 'Manish nagar', 'Nagpur', 'Maharashtra', 1200, 2600, 3120000, 'uploadImage/80.jpg'),
(80, 'Manish nagar', 'Nagpur', 'Maharashtra', 2100, 4523, 9500000, 'uploadImage/81.jpg'),
(81, 'Manish nagar', 'Nagpur', 'Maharashtra', 1500, 4333, 6500000, 'uploadImage/82.jpg'),
(82, 'Manish nagar', 'Nagpur', 'Maharashtra', 1360, 3800, 5168000, 'uploadImage/83.jpg'),
(83, 'Manish nagar', 'Nagpur', 'Maharashtra', 1800, 4200, 7560000, 'uploadImage/84.jpg'),
(84, 'Manish nagar', 'Nagpur', 'Maharashtra', 1350, 2650, 3577000, 'uploadImage/85.jpg'),
(85, 'Manish nagar', 'Nagpur', 'Maharashtra', 15000, 2850, 42800000, 'uploadImage/86.jpg'),
(86, 'Manish nagar', 'Nagpur', 'Maharashtra', 1450, 2750, 3988000, 'uploadImage/87.jpg'),
(87, 'Manewada', 'Nagpur', 'Maharashtra', 123, 1234, 1234567, 'uploadImage/land2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `land`
--
ALTER TABLE `land`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `land`
--
ALTER TABLE `land`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
