-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 09:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_alogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_alogin`
--

CREATE TABLE `tb_alogin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(30) NOT NULL,
  `city` varchar(255) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` bigint(15) NOT NULL,
  `aadhar` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_alogin`
--

INSERT INTO `tb_alogin` (`id`, `name`, `age`, `city`, `gender`, `contact`, `aadhar`, `username`, `email`, `password`) VALUES
(1, 'amit', 22, 'nagpur', 'Female', 2147483647, 1655145415, 'amit', 'amit@123', '123'),
(2, 'Vinay Thaware', 22, 'Nagpur', 'Male', 2147483647, 2147483647, 'vinay', 'vinay@123', '123'),
(3, 'Niket', 23, 'Nagpur', 'Male', 8605991388, 503236366340, 'iamniketpatil', 'patilniket41@gmail.com', 'niket');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_alogin`
--
ALTER TABLE `tb_alogin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_alogin`
--
ALTER TABLE `tb_alogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
